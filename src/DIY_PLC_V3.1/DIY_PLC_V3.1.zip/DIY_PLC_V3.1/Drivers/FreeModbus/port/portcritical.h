#ifndef _PORTCRITICAL_H_
#define _PORTCRITICAL_H_

void __critical_enter(void);
void __critical_exit(void);

#endif
